//---------------------------------------------------------------------------

#ifndef UuBitx03H
#define UuBitx03H
//---------------------------------------------------------------------------
#include <System.Classes.hpp>
#include <FMX.Controls.hpp>
#include <FMX.Forms.hpp>
//---------------------------------------------------------------------------
class TF3 : public TForm
{
__published:	// IDE-managed Components
private:	// User declarations
public:		// User declarations
	__fastcall TF3(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TF3 *F3;
//---------------------------------------------------------------------------
#endif
